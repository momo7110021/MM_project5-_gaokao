# 基于大数据和 AI 的高考志愿填报多目标推荐模型研究

---

## 摘要

高考志愿填报是每年涉及千万家庭的高利害决策问题。考生面临的核心挑战包括：不同年份高考分数不可直接比较、院校专业录取概率难以量化、志愿表冲稳保结构难以优化、专业就业前景难以评估、滑档退档等风险难以识别。本文提出了一套基于大数据和人工智能的高考志愿填报多目标推荐模型体系，包含五个核心模型：分数—位次等效换算模型（模型一）、院校/专业录取概率预测模型（模型二）、冲稳保志愿组合优化模型（模型三）、志愿填报风险评估模型（模型四）和专业就业景气度评价模型（模型五）。模型以多目标综合效用函数 `max U = αP_admit + βM_fit + γE_career + δC_city + ηR_family − λRisk` 为总框架，综合录取概率、专业匹配度、就业价值、城市价值和家庭资源匹配度五项正向指标，并引入风险惩罚项，实现对志愿表的全局优化。本文同时设计了覆盖七类公开数据（一分一段表、院校投档线、专业录取数据、招生计划、专业就业数据、城市产业数据、考生画像数据）的爬取、清洗与建库方案，明确了每类数据的来源、字段、爬取方式和清洗规则。模型输出统一 JSON 接口，可直接接入咨询系统或小程序。经模拟数据验证，本模型体系能够有效降低滑档风险，提高志愿表合理性，具备较好的工程落地能力和业务解释力。

**关键词**：高考志愿填报；位次等效换算；录取概率预测；多目标优化；风险评估；TOPSIS；贝叶斯修正；XGBoost

---

## 一、问题重述

### 1.1 问题背景

高考是中国大陆规模最大、影响最深远的教育选拔考试。每年约 1000 万考生在知晓成绩和位次后，需要在短短数日内，从数千所院校、数万个专业中完成志愿填报。不同省份的志愿填报规则各不相同（如"院校+专业组""专业+院校"等模式），且每年招生计划、报考人数、专业热度均会发生变化，使得历史数据的直接参考价值有限。

### 1.2 核心问题

本文需解决的六个核心问题：

1. **跨年度分数不可比问题**：今年 580 分与去年 580 分因试题难度、考生人数、招生计划等差异，代表的竞争力不同，需要建立科学的分数—位次等效换算方法。
2. **录取概率难以量化问题**：考生报考某院校、专业组或专业的录取概率需要基于历史数据和当年招生计划进行预测，而非依赖单一分数线。
3. **志愿表结构优化问题**：需要生成冲、稳、保、垫结构合理的完整志愿表，而非推荐单个学校。
4. **专业就业前景评估问题**：需要基于多源就业数据评估专业的就业景气度、行业成长性和冷门风险。
5. **多维度风险识别问题**：需要识别滑档、退档、调剂、冷门、就业、地域六类风险，给出预警和修正建议。
6. **模型输出可解释问题**：模型结果需要对家长可理解、咨询师可复核、系统可调用。

### 1.3 核心约束

- 数据需自行从公开来源爬取，不可使用现成数据集。
- 爬虫必须遵守法律法规，仅采集公开数据，不绕过反爬限制。
- 模型输出不得包含"保证录取""绝对安全"等违规表述。
- 模型需服务于业务，所有公式和算法必须可计算、可解释、可验证。

---

## 二、问题分析

### 2.1 问题链条

高考志愿填报问题的完整决策链条如下：

```
考生分数 → 位次换算 → 等效分映射 → 录取概率计算 → 专业匹配分析 →
就业前景评估 → 城市价值评估 → 家庭约束过滤 → 志愿组合优化 →
风险评估 → 志愿表输出
```

### 2.2 建模思路

本文采用**分层建模、逐层递进**的策略：

- **第一层（基础层）**：模型一，分数—位次等效换算，解决跨年分数不可比问题。
- **第二层（预测层）**：模型二，录取概率预测，量化每个志愿的录取可能性。
- **第三层（评价层）**：模型五，专业就业景气度评价，多维评估专业的就业价值。
- **第四层（决策层）**：模型三，志愿组合优化，在硬约束下生成结构合理的志愿表。
- **第五层（保障层）**：模型四，风险评估，识别六类风险并给出修正建议。

### 2.3 总体模型框架

本文建立如下多目标综合效用函数作为总模型（详见第七章）：

$$\max U = \alpha P_{admit} + \beta M_{fit} + \gamma E_{career} + \delta C_{city} + \eta R_{family} - \lambda R_{risk}$$

五个核心模型为该总函数提供五项正向指标和一项负向风险指标的计算基础。

---

## 三、数据来源、爬取与数据字典

### 3.1 数据爬取总原则

1. **合法合规**：只采集公开可访问的数据，不绕过登录、验证码、反爬限制或付费权限。
2. **访问限速**：每次请求间隔不少于 3 秒，避免对目标服务器造成压力。
3. **可追溯**：每条数据记录保留 `source_url`、`source_name`、`crawl_time`、`data_version`、`source_type`。
4. **分类解析**：对 HTML、PDF、Excel、CSV 采用不同解析方式（`requests`+`BeautifulSoup`、`pdfplumber`、`pandas`）。
5. **人工兜底**：对无法自动解析的数据设计人工导入模板。

### 3.2 七类数据采集器

本文在 `src/crawler.py` 中设计了七个具体采集器（均继承自 `BaseCrawler`），覆盖全部数据需求：

#### 3.2.1 SegmentTableCrawler：一分一段表

- **用途**：分数—位次等效换算模型的核心输入。
- **公开来源**：各省教育考试院官网、阳光高考平台。
- **格式**：HTML 表格 / PDF / Excel。
- **关键字段**：`province`, `year`, `subject_type`, `score`, `segment_count`, `cumulative_count`, `rank`, `percentile`, `batch_line`。
- **更新频率**：每年高考出分后更新。
- **人工备份**：若 PDF 解析失败，提供 `manual_import_template()` CSV 模板。

#### 3.2.2 AdmissionLineCrawler：院校投档线

- **用途**：录取概率预测模型的核心输入。
- **公开来源**：省教育考试院投档线公告、高校招生网。
- **格式**：HTML / PDF / Excel。
- **关键字段**：`province`, `year`, `batch`, `subject_type`, `school_code`, `school_name`, `major_group_code`, `min_admission_score`, `min_admission_rank`, `plan_count`, `admission_count`。

#### 3.2.3 MajorAdmissionCrawler：专业录取数据

- **用途**：专业录取概率预测和调剂风险评估。
- **公开来源**：高校招生网"历年录取分数"查询系统、省级招办分专业录取情况。
- **格式**：HTML / PDF。
- **关键字段**：`school_code`, `major_code`, `major_name`, `major_group_code`, `province`, `year`, `min_admission_score`, `min_admission_rank`, `avg_score`, `max_score`, `plan_count`, `admission_count`, `subject_requirement`, `adjustment_rule`。

#### 3.2.4 EnrollmentPlanCrawler：招生计划

- **用途**：志愿组合硬约束（选科、学费、学制、身体限制、单科限制）。
- **公开来源**：省教育考试院招生计划公告、高校招生章程。
- **格式**：HTML / PDF / Excel。
- **关键字段**：`school_code`, `major_code`, `major_name`, `province`, `year`, `plan_count`, `tuition`, `duration`, `subject_requirement`, `is_sino_foreign`, `is_normal_major`, `is_medical_major`, `single_subject_limit`, `physical_limit`。

#### 3.2.5 MajorEmploymentCrawler：专业就业数据

- **用途**：专业就业景气度评价模型的核心输入。
- **公开来源**：高校就业质量报告（PDF）、国家统计局、招聘网站公开岗位数据。
- **格式**：PDF / HTML / Excel。
- **关键字段**：`major_code`, `major_name`, `employment_rate`, `postgraduate_rate`, `civil_service_post_count`, `average_salary`, `median_salary`, `job_count`, `job_growth_rate`, `industry_growth_score`, `stability_score`, `sentiment_warning_score`, `data_year`, `sample_size`。
- **注意**：`sentiment_warning_score`（社媒舆情）仅为辅助预警字段，不参与核心 TOPSIS 计算。

#### 3.2.6 CityDataCrawler：城市产业数据

- **用途**：城市价值评估和扩展模型。
- **公开来源**：国家统计局、中国城市统计年鉴。
- **格式**：HTML / Excel。
- **关键字段**：`city`, `province`, `gdp`, `gdp_per_capita`, `tertiary_industry_ratio`, `key_industries`, `high_tech_company_count`, `listed_company_count`, `average_salary`, `living_cost`, `transport_score`。

#### 3.2.7 CandidateProfileCollector：考生画像

- **用途**：考生个性化约束和偏好。
- **来源**：前端问卷录入 / CSV 导入（非公开爬取）。
- **关键字段**：`candidate_id`, `province`, `year`, `subject_type`, `score`, `rank`, `interest_direction`, `strong_subjects`, `excluded_majors`, `preferred_cities`, `family_budget`, `risk_preference`, `accept_adjustment`, `accept_sino_foreign`, `accept_far_city`, `employment_first`, `postgraduate_first`。

### 3.3 source_trace 追溯体系

所有采集器输出的每行数据均携带以下五个追溯字段：

| 字段 | 说明 | 示例 |
|------|------|------|
| `source_url` | 数据来源 URL 或文件路径 | `http://www.hebeea.edu.cn/2024/segment.html` |
| `source_name` | 数据来源标识（采集器名称） | `segment_table` |
| `crawl_time` | 采集时间 | `2026-05-15 20:00:00` |
| `data_version` | 数据版本号 | `v1.0` |
| `source_type` | 来源类型 | `html` / `pdf` / `excel` / `manual` / `simulated` |

### 3.4 数据字典

完整数据字段字典见附录 D。七类数据覆盖 10 张数据库表：`segment_table`、`school_info`、`major_info`、`school_admission_line`、`major_admission`、`admission_plan`、`major_employment`、`city_data`、`candidate_profile`、`model_output`。

---

## 四、数据清洗与预处理

### 4.1 六级清洗流水线

所有原始数据进入数据库前统一经过以下清洗流水线：

1. **格式统一**：统一 UTF-8 编码、YYYY-MM-DD 日期格式、数值精度。
2. **缺失值处理**：关键字段缺失且无法推断的标记为无效；次要字段缺失对照同类数据均值/中位数填充并标记。
3. **异常值检测**：使用 IQR 方法（3倍四分位距）结合业务规则（分数须在 0-750、就业率须在 0-1 等）。
4. **一致性校验**：跨表关联校验（专业最低分 >= 院校投档线，容许 5 分偏差）；累计人数单调性校验。
5. **去重**：按业务主键组合去重。
6. **标准化**：省份名称（统一到"河北省"等 31 省）、院校名称（去除括号后缀）、专业名称（去除方向后缀）、院校代码（5 位补零）、专业代码（6 位补零）、科类（物理类/历史类/综合类统一映射）。

### 4.2 口径统一规则

- 院校代码以教育部标识码为基准，建立年份-代码对照表。
- 专业代码以《普通高等学校本科专业目录》为准。
- 传统高考省份"理科"映射为"物理类"，"文科"映射为"历史类"。
- 所有清洗操作保留 `source_url`、`source_name`、`crawl_time`、`data_version`。

---

## 五、模型假设

1. **历史可参考性假设**：在无重大政策变动的条件下，历史年份录取数据可作为当前年份录取概率估计的参考依据。
2. **位次稳定性假设**：同一高校同一专业在相近年份的录取位次具有较强的统计稳定性，其波动服从某种概率分布。
3. **考生行为理性假设**：考生填报志愿时主要依据分数位次、院校声誉、专业热度等可观测因素，不存在大规模非理性填报行为。
4. **数据独立性假设**：各个志愿的录取事件之间在给定考生位次条件下相互独立。
5. **招生章程合规假设**：招生章程中公布的选科要求、身体条件限制、单科成绩限制等是严格约束条件，不符合的考生不具有录取资格。
6. **就业数据时效性假设**：近三年的专业就业数据可以较好地反映未来 4-6 年的就业市场状况，但需承认该假设存在较大不确定性。
7. **考生偏好稳定性假设**：考生在问卷中填写的偏好信息真实反映了其意愿，且在志愿填报期间不发生重大变化。
8. **线性加权可加性假设**：各评价维度之间近似独立，可采用线性加权方式合成总效用。

---

## 六、符号说明

| 符号 | 含义 | 取值范围 |
|------|------|----------|
| $S$ | 考生当年原始分数 | 0-750 |
| $R$ | 考生当年位次 | 正整数 |
| $P_{ct}$ | 分位点 (percentile) | [0, 1] |
| $S_{eq}^{(t)}$ | 第 $t$ 年的等效分 | 0-750 |
| $\Delta_B$ | 批次线差 | 实数 |
| $w_t$ | 第 $t$ 年数据权重 | [0, 1] |
| $p_{admit}$ | 录取概率 | [0, 0.99] |
| $CI_{95\%}$ | 95% 置信区间 | — |
| $M_{fit}$ | 专业匹配度 | [0, 1] |
| $E_{career}$ | 专业就业价值 | [0, 1] |
| $C_{city}$ | 城市价值 | [0, 1] |
| $R_{family}$ | 家庭资源匹配度 | [0, 1] |
| $R_{risk}$ | 综合风险得分 | [0, 1] |
| $U$ | 综合效用 | [-1, 1] |
| $x_i$ | 第 $i$ 个志愿是否入选 | {0, 1} |
| $\alpha, \beta, \gamma, \delta, \eta, \lambda$ | 效用函数权重 | [0, 1] |
| $N_{rush}, N_{stable}, N_{safe}, N_{bottom}$ | 各层次志愿数量 | 正整数 |
| $N_{max}$ | 志愿表总容量 | 正整数 |

---

## 七、总模型：多目标志愿推荐函数

### 7.1 总体效用函数

本文以如下多目标综合效用函数作为总模型框架：

$$\max U = \alpha P_{admit} + \beta M_{fit} + \gamma E_{career} + \delta C_{city} + \eta R_{family} - \lambda R_{risk}$$

### 7.2 各指标说明

| 符号 | 含义 | 数据来源 | 计算方法 | 归一化 | 关联模型 |
|------|------|----------|----------|--------|----------|
| $P_{admit}$ | 录取概率 | 历史投档线、专业录取位次、招生计划 | Logistic+XGBoost+贝叶斯+蒙特卡洛融合 | 已在 [0, 0.99] | 模型一 + 模型二 |
| $M_{fit}$ | 专业匹配度 | 考生兴趣方向、优势科目 | 兴趣关键词匹配度 | [0, 1] | 扩展模型 |
| $E_{career}$ | 就业价值 | 就业率、薪资、岗位数、成长性 | AHP+熵权+TOPSIS | [0, 1] | 模型五 |
| $C_{city}$ | 城市价值 | GDP、产业结构、高新企业数、薪资、生活成本 | 加权线性评分 | [0, 1] | 扩展模型 |
| $R_{family}$ | 家庭匹配度 | 家庭预算、偏好城市、排斥专业 | 约束满足度 | [0, 1] | 扩展模型 |
| $R_{risk}$ | 综合风险 | 志愿表整体特征 | 蒙特卡洛+风险矩阵 | [0, 1] | 模型四 |

### 7.3 三类方案权重表

| 方案类型 | $\alpha$ | $\beta$ | $\gamma$ | $\delta$ | $\eta$ | $\lambda$ | 冲:稳:保:垫 |
|----------|----------|----------|----------|----------|----------|----------|-------------|
| 激进型(aggressive) | 0.15 | 0.25 | 0.30 | 0.15 | 0.15 | 0.10 | 4:3:2:1 |
| 均衡型(balanced) | 0.25 | 0.25 | 0.20 | 0.10 | 0.15 | 0.05 | 2:3:3:2 |
| 保守型(conservative) | 0.35 | 0.15 | 0.10 | 0.10 | 0.20 | 0.10 | 1:2:3:4 |

### 7.4 三类业务解释

**家长端**：
"系统综合分析了您的分数、位次、兴趣和家庭偏好。推荐方案考虑了您被录取的可能性（录取概率）、专业的就业前景（就业评分）、学校所在城市的发展机会（城市评分）以及整体风险。您可以选择偏冲、均衡或偏保守的方案。"

**咨询师端**：
"该方案基于五维度加权效用函数 `max U = αP_admit + βM_fit + γE_career + δC_city + ηR_family − λRisk`。考生选择了均衡型方案(α=0.25)。各指标来源于模型一至五的输出。您可在此基表上编辑志愿顺序或替换院校专业，系统会重新计算风险和效用。"

**系统后台**：
统一 JSON 输出，对应字段：`candidate` 块含 `risk_preference`, `equivalent_scores`；`recommendation_plan` 块含 `volunteers[*].overall_utility`、`statistics.overall_score`。

---

## 八、模型一：分数—位次等效换算模型

### 8.1 业务问题

今年 580 分与去年 580 分因试卷难度、考生规模、招生计划不同，代表的竞争力完全不同。需要将考生当年的分数和位次映射为历史年份中的"等效分"，才能与往年录取数据进行比较。**位次比分数更稳定**——位次反映考生在全体考生中的相对位置，受试卷难度影响较小。

### 8.2 输入数据

一分一段表（`segment_table`），含各年份各科类的分数、本段人数、累计人数、位次、分位点，以及批次线。

### 8.3 数据来源

`SegmentTableCrawler` 从各省教育考试院官网/阳光高考采集，支持 HTML/PDF/Excel 格式。

### 8.4 数学模型

**步骤 1**：计算考生当前分位点。

$$P_{ct}(S) = \frac{\text{CumulativeCount}(S)}{N_{total}}$$

**步骤 2**：分位数映射。在目标年份 $t$ 的一分一段表中寻找与 $P_{ct}$ 最接近的累计人数对应的分数：

$$S_{eq}^{(t)} = \arg\min_s \left| \frac{\text{CumCount}_t(s)}{N_{total,t}} - P_{ct} \right|$$

**步骤 3**：线性插值。设分位点 $p$ 落在分数 $s_1$ 和 $s_2$（$s_1 < s_2$）对应的分位点 $p_1$ 和 $p_2$ 之间，则：

$$S_{eq}^{(t)} = s_1 + \frac{p - p_1}{p_2 - p_1} \times (s_2 - s_1)$$

**步骤 4**：线差修正。

$$S_{eq,adj}^{(t)} = S_{eq}^{(t)} + \theta \times [(B^{(0)} - B^{(t)}) \times (1 - P_{ct})]$$

其中 $\theta=0.3$ 为修正系数，$(1 - P_{ct})$ 使线差修正对高分考生影响较小，对低分考生影响较大。

**步骤 5**：异常年份降权。定义波动异常度 $\sigma_t$，使用 softmax 计算各年权重：

$$w_t = \frac{\exp(-\sigma_t / \tau)}{\sum_{t'} \exp(-\sigma_{t'} / \tau)}$$

其中 $\tau=1000$ 为温度参数。若 $\sigma_t > 3 \times \text{median}(\sigma)$，标记为异常年份。

**步骤 6**：多年度加权等效分。

$$S_{eq}^* = \sum_{t \in T} w_t \times S_{eq}^{(t)}$$

**步骤 7**：95% 置信区间。

$$S_{eq}^* \pm 1.96 \times \sigma_S, \quad \sigma_S = \sqrt{\frac{\sum w_t (S_{eq}^{(t)} - S_{eq}^*)^2}{\sum w_t}}$$

### 8.5 求解流程

```
输入: 考生分数S, 位次R, 当前年份y0, 目标年份列表T, 批次线B
1. 计算分位点 Pct = R / N_total
2. FOR t IN T:
   a. 读取第t年一分一段表
   b. 在表中找到包含Pct的分数区间
   c. 线性插值得到Seq_raw
   d. 线差修正: Seq_adj = Seq_raw + theta*((B0-Bt)*(1-Pct))
3. 计算各年波动异常度sigma_t
4. 计算各年权重w_t = softmax(-sigma_t/tau)
5. 识别异常年份(sigma_t > 3*median(sigma))
6. 加权等效分 Seq_star = sum(w_t * Seq_t)
7. 计算标准差和95%CI
8. 判断confidence_level: sigma_S<=3→high, <=8→medium, >8→low
```

### 8.6 输出字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `equivalent_score` | float | 加权等效分 |
| `equivalent_score_interval` | [float, float] | 95% CI 区间 |
| `equivalent_rank` | int | 等效位次 |
| `percentile` | float | 分位点 |
| `confidence_level` | str | high/medium/low |
| `abnormal_year_warning` | bool | 是否存在异常年份 |
| `fallback_rule` | str | 回退规则（normal/insufficient_data） |
| `review_required` | bool | 是否需要人工复核 |

### 8.7 评价指标

| 指标 | 目标值 |
|------|--------|
| 留一验证 MAE | < 3 分 |
| 95% CI 覆盖率 | > 90% |
| 异常年份识别率 | > 80% |

### 8.8 业务解释

**家长端**："您今年考了 620 分，在全省排第 8500 名。相当于往年约 618 分（区间 610-628 分）。这是因为每年试卷难度和考生人数不同，不能直接用今年分数比较往年录取分数。位次比分数更稳定，我们用您在全省考生中的相对位置来换算。"

**咨询师端**："等效分换算方法：分位数映射+线差修正(theta=0.3)+异常年份降权(tau=1000)。置信度：high。等效分区间宽度 18 分以下表示换算较稳定。无异常年份。"

**系统后台**：结构化字段含 `method`、`parameters`、`source_table`、`result`。

### 8.9 局限性与改进方向

分位点守恒假设在高校大幅扩招或缩招时可能失效，后续可引入招生计划变化率修正因子。

---

## 九、模型二：院校/专业录取概率预测模型

### 9.1 业务问题

给定考生等效位次和目标院校/专业的历史录取数据，估计被录取的概率 $p_{admit}$，并给出置信区间和冲、稳、保、垫推荐等级。

### 9.2 输入数据

- 历年院校投档线（`school_admission_line`）
- 历年专业录取数据（`major_admission`，含最低分/位次、平均分、最高分、计划数、录取数）
- 招生计划数据（`admission_plan`，含计划变化率）

### 9.3 特征工程

| 特征 | 含义 | 构造方式 |
|------|------|----------|
| `rank_gap_mean` | 位次差均值 | mean(candidate_rank − hist_min_rank) |
| `rank_gap_std` | 位次差标准差 | std(hist_min_rank) |
| `rank_gap_min` | 最危险年份的位次差 | candidate_rank − min(hist_min_rank) |
| `rank_gap_trend` | 位次差趋势 | 线性回归斜率 |
| `rank_volatility` | 录取位次波动系数 | std/min(录取位次) |
| `plan_change_rate` | 招生计划变化率 | (plan_current − plan_last) / plan_last |
| `score_diff_mean` | 等效分差均值 | 等效分 − 历年最低分均值 |
| `years_with_data` | 数据年份数 | 反映数据充分性 |
| `popularity_factor` | 热度因子 | 基于报考热度（默认1.0） |
| `subject_requirement_match` | 选科匹配 | 0/1 |

### 9.4 数学模型：四方法融合

**方法一**：Logistic 回归基准模型。

$$\log\left(\frac{p}{1-p}\right) = \beta_0 + \sum_{i=1}^{m} \beta_i x_i$$

**方法二**：XGBoost 梯度提升模型。参数：n_estimators=200, max_depth=5, learning_rate=0.05。自动捕获特征间的非线性交互。

**方法三**：贝叶斯修正。对于数据年数 $n \leq 2$ 的小样本专业，使用 Beta-Binomial 先验平滑：

$$p_{bayes} = \frac{\alpha_0 + \text{successes}}{\alpha_0 + \beta_0 + n}$$

其中先验参数 $(\alpha_0, \beta_0)$ 从同层次同类型专业统计中矩估计。

**方法四**：蒙特卡洛模拟。从历史录取位次分布中抽样 $M=10000$ 次，每次模拟一个"最低录取位次"并与考生位次比较：

$$p_{mc} = \frac{1}{M} \sum_{m=1}^{M} \mathbf{1}[R_{cand} \leq E_{min}^{sim,m}]$$

模拟中纳入招生计划变化率修正：$E_{min}^{sim,m} = E_{min}^{hist} \times (1 + \eta \cdot \Delta_{plan}) + \epsilon_m$，$\epsilon_m \sim N(0, \sigma_{vol}^2)$。

**融合权重**：$p_{final} = 0.15 p_{LR} + 0.35 p_{XGB} + 0.20 p_{Bayes} + 0.30 p_{MC}$。

**概率上限**：$p_{final}$ 强制不超过 0.99，不允许输出 100%。

### 9.5 省份/科类/选科组合校正

不同省份、不同科类、不同选科组合的录取概率模型不可直接混用。具体校正依据院校层次和样本量做粗略修正，真实上线需使用按省份/科类/选科组合分层后的历史数据进行回测校准。

### 9.6 小样本专业处理

对 $n \leq 2$ 的专业：概率区间宽度扩大为原来的 $(1 + (3-n) \times 1.5)$ 倍；`uncertainty_level` 设为 `high`；`review_required` 设为 `True`。

### 9.7 冲/稳/保/垫映射

| 等级 | 概率区间 | 含义 |
|------|----------|------|
| high\_risk\_rush (高风险冲) | $p < 0.20$ | 录取概率极低，视为高风险冲刺，计入 rush\_count，但触发 review\_required 和人工复核 |
| rush (冲) | $p < 0.45$（含 p < 0.20 的高风险项） | 录取概率偏低，属于冲刺志愿。代码中 p < 0.20 和 0.20 ≤ p < 0.45 均返回 "rush"，其中 p < 0.20 额外标记 high\_risk\_rush |
| stable (稳) | $0.45 \leq p < 0.70$ | 有较大希望被录取 |
| safe (保) | $0.70 \leq p < 0.88$ | 基本可录取 |
| bottom (垫) | $p \geq 0.88$ | 几乎确保录取，为兜底志愿 |

注意：以上阈值仅为默认值，实际使用时应按省份、批次和年份回测数据校准。代码实际阈值配置为 rush\_threshold=0.20, stable\_threshold=0.45, safe\_threshold=0.70, bottom\_threshold=0.88，对应 classfiy\_tier 逻辑为：p ≥ 0.88→bottom, p ≥ 0.70→safe, p ≥ 0.45→stable, 其余→rush。

### 9.8 输出字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `admit_probability` | float [0, 0.99] | 录取概率 |
| `probability_interval` | [float, float] | 概率区间 |
| `recommendation_tier` | str | rush/stable/safe/bottom |
| `uncertainty_level` | str | low/medium/high |
| `top_features` | list | 影响最大的3-5个特征 |
| `review_required` | bool | 是否需要人工复核 |
| `n_years_data` | int | 可用历史数据年数 |
| `component_probabilities` | dict | 四方法分量概率 |
| `explanation` | str | 家长端解释 |
| `consultant_explanation` | str | 咨询师端解释 |
| `backend_explanation` | dict | 系统后台结构 |
| `modification_suggestion` | str | 修改建议 |

### 9.9 评价指标

| 指标 | 目标值 |
|------|--------|
| AUC | > 0.85 |
| Brier Score | < 0.15 |
| 校准曲线斜率 | 接近 1 |
| 小样本专业区间覆盖率 | > 80% |

### 9.10 业务解释

**家长端**："报考 A大学的计算机科学与技术专业，预估录取概率约 65%（区间 58%-78%），属于'稳'的范畴。该专业近 3 年录取位次在 12000-15000 名之间，您当前位次 14000 名处于中等偏上位置，有较大希望。"

**咨询师端**："候选志愿 A 的位次差均值 +1200，概率 65%，建议列为稳类。近 3 年招生计划稳定，位次波动系数 0.08（低），数据充分（5 年）。分项概率：LR=0.60, XGB=0.68, Bayes=0.62, MC=0.67。"

**系统后台**：`{"method": "multi_model_fusion", "fusion_weights": {"lr":0.15,"xgb":0.35,"bayes":0.20,"mc":0.30}, "thresholds": {"rush":0.20,"stable":0.45,"safe":0.70,"bottom":0.88}, "is_trained": true}`

### 9.11 局限性与改进方向

当前代码支持 `fit_all()` 使用模拟数据训练。真实上线前必须使用按省份、科类、选科组合分层后的真实历史数据重新训练、回测和校准。新开设专业仅 1-2 年数据时，贝叶斯先验的选择对结果影响较大，可引入层次先验。

---

## 十、模型三：冲稳保志愿组合优化模型

### 10.1 业务问题

在满足考生全部硬约束的前提下，从候选志愿集合中选出一组冲稳保垫结构合理的完整志愿表，使综合效用最大化。

### 10.2 数学模型

目标函数采用总效用函数的离散形式：

$$\max \sum_{i} x_i \left[ \alpha P_{admit,i} + \beta M_{fit,i} + \gamma E_{career,i} + \delta C_{city,i} + \eta R_{family,i} - \lambda R_{risk,i} \right]$$

其中 $x_i \in \{0, 1\}$ 为决策变量。

### 10.3 硬约束

1. **数量约束**：$\sum_i x_i \leq N_{max}$（默认 40）。
2. **比例约束**：$N_{rush}:N_{stable}:N_{safe}:N_{bottom}$ 按方案类型约束（激进 4:3:2:1，均衡 2:3:3:2，保守 1:2:3:4）。
3. **排斥专业过滤**：$x_i = 0$ 若 $major\_code \in excluded\_majors$。
4. **选科要求过滤**：$x_i = 0$ 若不符合 `subject_requirement`。
5. **学费预算约束**：$x_i = 0$ 若 $tuition > family\_budget$。
6. **地域约束**：若 $accept\_far\_city = 0$，则 $x_i = 0$ 若 $city \notin preferred\_cities$。
7. **身体/单科限制**：$x_i = 0$ 若触发 `physical_limit` 或 `single_subject_limit`。
8. **高风险志愿上限**：高风险志愿数量 $\leq 5$。
9. **保底层覆盖**：$N_{bottom} \geq \text{ratio} \times N_{max}$，确保极端波动下不滑档。

### 10.4 求解方法

采用"硬约束过滤 → 分层候选池 → 多目标评分 → 比例约束 + 贪心初始化 + 局部搜索优化"两阶段方法：

- **阶段一**：按硬约束过滤候选集，计算每个候选志愿的综合效用 $U_i$。
- **阶段二**：按概率分为 rush/stable/safe/bottom 四个子池，在每个子池内按 $U$ 降序贪心选取目标数量，然后进行 $N_{local\_search}=100$ 次随机替换局部搜索（尝试用更高 $U$ 的同层候选替换已入选志愿）。

### 10.5 输出字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `volunteer_list` | list | 志愿表 |
| `plan_type` | str | aggressive/balanced/conservative |
| `rush_count` | int | 冲刺志愿数 |
| `stable_count` | int | 稳妥志愿数 |
| `safe_count` | int | 保底志愿数 |
| `bottom_count` | int | 垫底志愿数 |
| `overall_score` | float | 综合效用均值 |
| `overall_risk_level` | str | 综合风险等级 |
| `adjustment_suggestion` | str | 调整建议 |
| `review_required` | bool | 是否需要人工复核 |
| `editable` | bool | 是否可编辑 |

### 10.6 评价指标

| 指标 | 目标值 |
|------|--------|
| 冲稳保垫比例达标率 | > 90% |
| 硬约束满足率 | 100% |
| 局部搜索效用提升 | > 5% |

### 10.7 业务解释

**家长端**："为您推荐一组冲、稳、保、垫结构的志愿表。系统将录取概率低于 20% 的志愿列为高风险冲刺项（仍计入冲类，需咨询师复核），20%-45% 视为'冲'，45%-70% 视为'稳'，70%-88% 视为'保'，88% 以上视为'垫'。已根据您的排斥专业、预算和偏好城市进行过滤。"

**咨询师端**："均衡型方案(2:3:3:2)，目标效用函数权重 α=0.25。硬约束全部满足。建议检查垫底志愿是否覆盖今年可能的位次波动；考虑是否增加偏远 985 院校的冲刺志愿。"

---

## 十一、模型四：志愿填报风险评估模型

### 11.1 业务问题

从不确定性角度识别志愿方案中的潜在风险，定量评估六类风险并给出预警和修正建议。

### 11.2 六类风险

| 风险 | 评估方法 | 风险因素 |
|------|----------|----------|
| **滑档风险** ($R_{slip}$) | 蒙特卡洛模拟所有志愿同时失败的概率 | 保底不足、冲太多 |
| **退档风险** ($R_{withdrawal}$) | 超录比例 + 体检/单科不达标概率 | 招生章程限制 |
| **调剂风险** ($R_{adjust}$) | 专业组内冷热差异 + 是否接受调剂 | 专业组结构、accept_adjustment |
| **冷门风险** ($R_{cold}$) | 录取概率加权后的就业评分 | 就业评分低、岗位少 |
| **就业风险** ($R_{employment}$) | 整体志愿表就业评分均值 | career_score 偏低 |
| **地域风险** ($R_{region}$) | 偏好城市覆盖率 | 地域约束未满足 |

综合风险评分：

$$R_{risk} = 0.30 R_{slip} + 0.25 R_{withdrawal} + 0.20 R_{adjust} + 0.10 R_{cold} + 0.10 R_{employment} + 0.05 R_{region}$$

分级：critical (>0.50) / high (>0.30) / medium (>0.15) / low (≤0.15)。

### 11.3 十大典型问题扫描

1. Q1: 冲志愿超过 50%
2. Q2: 稳志愿不足 20%
3. Q3: 滑档风险 > 5%
4. Q4: 专业组冷热差异 > 0.7
5. Q5: 用户排斥专业被纳入
6. Q6: 30% 以上专业就业评分 < 0.3
7. Q7: 偏好城市覆盖率 < 30%
8. Q8: 历史位次波动 > 0.25
9. Q9: 小样本专业概率过度乐观
10. Q10: 调剂风险 > 0.7 且接受调剂

### 11.4 输出字段

每类风险输出独立字段：

| 字段 | 说明 |
|------|------|
| `{risk_name}.score` | 该项风险评分 |
| `{risk_name}.level` | high/medium/low |
| `{risk_name}.trigger_reason` | 触发原因 |
| `{risk_name}.modification_suggestion` | 具体修改建议 |
| `{risk_name}.review_required` | 是否需要复核 |

总体输出：

| 字段 | 类型 | 说明 |
|------|------|------|
| `overall_risk_score` | float | 综合风险评分 |
| `risk_level` | str | critical/high/medium/low |
| `slip_risk` | dict | 滑档风险详情 |
| `withdrawal_risk` | dict | 退档风险详情 |
| `adjustment_risk` | dict | 调剂风险详情 |
| `cold_major_risk` | dict | 冷门专业风险详情 |
| `employment_risk` | dict | 就业风险详情 |
| `region_risk` | dict | 地域风险详情 |
| `risk_reason` | list | 识别到的问题列表 |
| `modification_suggestion` | str | 综合修改建议 |
| `review_required` | bool | 是否需要人工复核 |

### 11.5 业务解释

**家长端**："经评估，您的志愿表综合风险为中等。主要风险是：保底志愿偏少（冲类志愿占比偏高），建议增加 2-3 个录取概率高于 88% 的兜底志愿。"

**咨询师端**："综合风险评分 0.18(medium)。滑档风险 0.05(触发预警)、调剂风险 0.15(由于专业组内冷热差异)。触发 Q3 问题：保底志愿不足。建议增加保底志愿。"

---

## 十二、模型五：专业就业景气度评价模型

### 12.1 业务问题

专业不能只看名字。需要从就业率、薪资、岗位数量、行业增长率、稳定性等多维度综合评价专业的就业景气度，输出红黄绿标签和细分评分，区分本科直接就业和读研后就业价值。

### 12.2 输入数据

| 指标 | 数据来源 | 口径说明 |
|------|----------|----------|
| 就业率 | 高校就业质量报告 | 毕业去向落实率（含升学） |
| 升学率 | 同上 | 国内升学率 |
| 平均/中位数薪资 | 就业报告+国家统计局+招聘网站 | 月薪，各来源口径有差异 |
| 招聘岗位数 | 招聘网站公开岗位 | 近一年发布量 |
| 岗位增长率 | 同上 | 同比增长率 |
| 考公岗位数 | 国考/省考职位表 | 近三年对专业岗位数 |
| 行业成长性 | 行业研究报告 | 1-10 分 |
| 稳定度 | 综合评估 | 1-10 分 |
| 社媒舆情 | 社交媒体分析 | 辅助预警，不参与核心评分 |

### 12.3 数学模型

采用 AHP—熵权—TOPSIS—聚类 四步法：

**步骤 1**：Min-Max 归一化（正向/负向指标分开处理）。

**步骤 2**：AHP 主观权重（9 指标，$\sum w_j^{AHP}=1$）。就业率 0.13，升学率 0.07，均薪 0.20，中位薪资 0.15，岗位数 0.13，岗位增长率 0.10，行业成长 0.10，稳定性 0.05，考公岗位 0.07。

**步骤 3**：熵权法客观权重。利用信息熵计算各指标差异度权重：

$$e_j = -k \sum p_{ij} \ln p_{ij}, \quad d_j = 1 - e_j$$

**步骤 4**：组合权重 $w_j^{comb} = w_j^{AHP} \times w_j^{entropy}$（归一化后）。

**步骤 5**：TOPSIS 计算综合接近度 $C_i$（即 `career_score`）。

$$C_i = \frac{D_i^-}{D_i^+ + D_i^-}, \quad D_i^+ = \sqrt{\sum_j w_j^{comb}(v_{ij} - v_j^+)^2}, \quad D_i^- = \sqrt{\sum_j w_j^{comb}(v_{ij} - v_j^-)^2}$$

**步骤 6**：KMeans 三分类聚类生成红（$C_i$ 低）、黄（$C_i$ 中）、绿（$C_i$ 高）标签。

**社媒舆情处理**：`sentiment_warning_score` 不纳入 TOPSIS 核心指标，仅作为辅助预警——当舆情分数高于 0.5 时触发 `review_required`。

### 12.4 细分评分

| 细分评分 | 计算方式 | 说明 |
|----------|----------|------|
| `salary_score` | average_salary + median_salary 归一化均值 | 薪资评分 |
| `stability_score` | stability_score/10 + civil_service_post/500 归一化 | 稳定度 |
| `growth_score` | job_growth_rate + industry_growth_score 组合 | 成长性 |
| `postgraduate_value_score` | postgraduate_rate × 1.5 + 学科加成 | 读研后价值 |
| `civil_service_score` | civil_service_post_count / 500 | 考公适配度 |
| `cold_major_risk_score` | 四维度（就业率+岗位数+增长率+career_score）加权求和 | 冷门风险 |

### 12.5 输出字段

| 字段 | 类型 | 说明 |
|------|------|------|
| `career_score` | float [0, 1] | 综合就业景气度 |
| `employment_level` | str | low/medium/high |
| `salary_score` | float [0, 1] | 薪资评分 |
| `stability_score` | float [0, 1] | 稳定性评分 |
| `growth_score` | float [0, 1] | 成长性评分 |
| `postgraduate_value_score` | float [0, 1] | 读研后价值 |
| `civil_service_score` | float [0, 1] | 考公适配度 |
| `cold_major_risk_score` | float [0, 1] | 冷门风险 |
| `major_risk_label` | str | safe/low_risk/medium_risk/high_risk |
| `red_yellow_green_label` | str | green/yellow/red |
| `trend_label` | str | improving/stable/declining/no_data |
| `salary_source_explanation` | dict | 薪资来源与口径说明 |
| `data_reliability_level` | str | high/medium/low |
| `explanation` | str | 家长端解释 |
| `consultant_explanation` | str | 咨询师端解释 |
| `backend_explanation` | dict | 系统后台结构 |
| `review_required` | bool | 是否需要人工复核 |

### 12.6 业务解释

**家长端**："计算机科学与技术的综合就业景气度为较好（绿色标签）。近年就业落实率约 94%，相关岗位月薪参考约 8000-9000 元（不同城市和行业有差异）。该专业就业面较广，但具体收入和发展还与个人能力、城市选择相关。"

**咨询师端**："计算机科学与技术 career_score=0.85(green)。薪资评分 0.71，成长性 0.33，稳定度 0.94，读研价值 0.48，考公适配度 0.24。数据可靠性：high（来自就业质量报告+招聘数据）。注意：薪资数据来源多样，口径不完全统一；社媒舆情未触发预警。"

**当前为模拟数据版本**，真实上线前必须使用高校就业质量报告、招聘岗位数据、统计年鉴和人工校验后的真实数据重新计算、回测和校准。

---

## 十三、扩展模型说明

本章简要说明二期增强模型（不作为主线但为系统扩展预留接口）。

### 13.1 城市—专业—产业匹配模型

基于 `CityDataCrawler` 采集的城市产业数据，构建城市产业与专业就业的匹配度矩阵。例如：深圳高新企业数（18000+）与计算机类专业的匹配度高；石家庄医药产业与临床医学专业的匹配度高。输出 `city_major_match_score`。

### 13.2 考生兴趣与专业匹配模型

基于考生 `interest_direction` 和 `strong_subjects` 与专业目录进行关键词匹配（当前在 pipeline step6 中已实现基础版本）。可扩展为基于专业课程描述的 TF-IDF/NLP 语义匹配。

### 13.3 推荐解释生成模型

在以上模型基础上，为每位考生的最终志愿表自动生成家长可读的推荐报告（pipeline 已实现 `generate_business_report()` 基础版本）。

---

## 十四、统一接口输出标准

### 14.1 总输出结构

统一 JSON（`pipeline.generate_output()`）结构如下：

```json
{
  "meta": {"model_version": "v3.0.0", "generate_time": "...", "data_disclaimer": "..."},
  "candidate": { ... },
  "recommendation_plan": {
    "plan_type": "balanced",
    "volunteers": [ ... ],
    "statistics": { ... },
    "risk_assessment": { ... }
  }
}
```

### 14.2 candidate 块字段

`candidate_id`, `province`, `year`, `subject_type`, `score`, `rank`, `equivalent_scores`, `equivalent_score`, `equivalent_score_interval`, `equivalent_rank`, `confidence_level`, `abnormal_year_warning`, `fallback_rule`, `risk_preference`, `source_trace`。

### 14.3 volunteers[*] 逐志愿字段

`volunteer_id`, `school_code`, `school_name`, `major_group_code`, `major_code`, `major_name`, `admit_probability`, `probability_interval`, `recommendation_tier`, `fit_score`, `career_score`, `city_score`, `family_score`, `risk_level`, `risk_reason`, `overall_utility`, `explanation`, `modification_suggestion`, `review_required`, `source_trace`。

### 14.4 risk_assessment 块字段

`overall_risk_score`, `risk_level`, `slip_risk`(dict), `withdrawal_risk`(dict), `adjustment_risk`(dict), `cold_major_risk`(dict), `employment_risk`(dict), `region_risk`(dict), `risk_reason`(list), `modification_suggestion`(str), `review_required`(bool)。

### 14.5 source_trace 子结构

`source_url`, `source_name`, `crawl_time`, `data_version`, `source_type`。

完整 JSON 示例见附录 C。

---

## 十五、模型评价与验收标准

### 15.1 技术验收指标

| 序号 | 指标 | 目标值 | 当前状态 |
|------|------|--------|----------|
| 1 | 数据爬取成功率 | > 90% | 待真实URL部署 |
| 2 | 字段完整率 | > 95% | 模拟数据 100% |
| 3 | 等效分 MAE | < 3 分 | 模拟数据集可实现 |
| 4 | 录取概率 AUC | > 0.85 | 模拟训练 0.94+（需交叉验证） |
| 5 | Brier Score | < 0.15 | 待真实数据校准 |
| 6 | 志愿结构约束满足率 | 100% | 硬约束全满足 |
| 7 | 风险识别准确率 | > 85% | 待人工标注验证 |
| 8 | 接口响应时间 | < 5 秒（含 8 步全流程） | 模拟数据 < 3 秒 |
| 9 | 同一输入结果可复现性 | 100% | 固定 seed 可复现 |

### 15.2 业务验收指标

| 序号 | 指标 | 目标值 |
|------|------|--------|
| 1 | 咨询师使用意愿 | > 70%（内测） |
| 2 | 家长理解度（能复述推荐理由） | > 80% |
| 3 | 高风险推荐人工复核触发率 | 10%-30% |
| 4 | 是否避免违规话术 | 100%（已检查） |
| 5 | 报告可交付性 | 一键生成 markdown 报告 |
| 6 | 接口可接入性 | 统一 JSON/可接入小程序后端 |

---

## 十六、测试案例集设计

### 16.1 测试案例

| # | 案例名 | 输入 | 预期输出 | 触发风险 | 验收点 |
|---|--------|------|----------|----------|--------|
| 1 | 冲 | score=650, rank=500, P≈0.10 | tier=rush | 滑档风险高 | 被标记为冲 |
| 2 | 稳 | score=620, rank=8500, P≈0.35 | tier=stable | 低 | 被标记为稳 |
| 3 | 保 | score=590, rank=20000, P≈0.65 | tier=safe | 无 | 被标记为保 |
| 4 | 垫 | score=550, rank=50000, P≈0.92 | tier=bottom | 无 | 被标记为垫 |
| 5 | 高分冲名校 | score=680, rank=500 | 等效分区间窄 | 置信度高 | CI 宽度 < 15 分 |
| 6 | 中分均衡型 | score=550, rank=50000, plan=balanced | 2:3:3:2 比例 | — | 比例达标 |
| 7 | 低分保底型 | score=450, rank=150000, plan=conservative | 1:2:3:4 比例 | 就业风险 | 底部覆盖 |
| 8 | 不接受调剂 | accept_adjustment=0 | 调剂风险×1.5 | 调剂风险高 | 预警触发 |
| 9 | 排斥专业 | excluded=["哲学","历史学"] | 过滤排除专业 | — | 志愿表无排除 |
| 10 | 家庭预算受限 | budget=5000 | 过滤 tu>5000 | — | 志愿表无超预算 |
| 11 | 地域约束 | preferred=["北京","上海"] | C_city 加权 | 地域风险 | 偏好城市占比 |
| 12 | 异常年份 | sigma_t > 3×median(sigma) | abnormal_year_warning | 等效分不确定 | confidence=low |
| 13 | 小样本专业 | n_years ≤ 2 | review_required | 概率不确定高 | uncertainty=high |
| 14 | 就业高风险 | 土木类, E_career≈0.25 | red_label | 就业+冷门风险 | 警告输出 |

### 16.2 测试文件映射

| 测试文件 | 覆盖案例 | 验收点 |
|----------|----------|--------|
| `tests/test_equivalent_score.py` | #5, #12 | 等效分 MAE, CI 覆盖率 |
| `tests/test_admission_probability.py` | #1, #2, #13 | 概率区间, tier 映射 |
| `tests/test_career_evaluation.py` | #14 | career_score, 红黄绿标签 |
| `tests/test_volunteer_optimizer.py` | #3, #4, #9, #10 | 硬约束满足, 比例达标 |
| `tests/test_risk_assessment.py` | #8, #11 | 风险触发, 10类问题 |
| `tests/test_pipeline.py` | #6, #7 | 全流程端到端 |

### 16.3 测试运行方式

```bash
python main.py --test              # 运行内置测试案例集
pytest tests/ -v                   # 运行 pytest 测试套件
```

---

## 十七、模型优缺点分析

### 17.1 优点

1. **完整的业务链路**：从数据爬取到志愿表输出，覆盖完整的"数据→模型→接口→解释"链路。
2. **多模型融合**：录取概率模型融合 Logistic、XGBoost、贝叶斯和蒙特卡洛四种方法，互补短长。
3. **可解释性强**：每个模型均包含家长端、咨询师端和后台三类解释，降低使用门槛。
4. **硬约束覆盖全面**：志愿优化模型包含选科、学费、地域、身体条件、单科成绩等 10 项硬约束。
5. **风险识别体系完善**：六类风险 + 十大典型问题扫描，防止严重填报失误。
6. **统一 JSON 接口**：所有输出字段标准化，可直接接入小程序或咨询系统后台。
7. **合规设计**：所有采集方法遵循合法合规原则，不绕过安全机制；概率上限 0.99，不含违规话术。

### 17.2 缺点

1. **依赖历史数据**：录取概率模型效果取决于历史数据的完整性和准确性，新开设专业仅有 1-2 年数据时不确定性较高。
2. **就业数据时效性**：当前缺乏完整的多年度真实就业时间序列，趋势分析能力受限。
3. **权重主观性**：AHP 权重和总效用函数权重虽参考了专家经验，但仍具有一定主观性，需通过 A/B 测试持续优化。
4. **省份/科类分层不足**：当前省份和科类校正为简化实现，真实上线需做完整的分层回测。
5. **模拟数据局限**：当前所有测试基于模拟数据，模型的实际泛化能力需在真实数据集上验证。

---

## 十八、实施路线与交付计划

| 阶段 | 时间 | 核心任务 | 交付物 |
|------|------|----------|--------|
| **第一阶段：基础模型** | 第 1 个月 | 完成等效分换算、录取概率预测、冲稳保志愿优化初版；搭建爬虫框架和清洗流水线 | 可运行 pipeline、基础 JSON 输出 |
| **第二阶段：增强模型** | 第 2 个月 | 完成就业景气评价(含真实数据接入)、风险评估(全十类问题)、城市匹配、兴趣匹配；补全三类解释和 markdown 报告生成 | 完整推荐报告、评估报告 |
| **第三阶段：系统化** | 第 3 个月 | 接口联调、前端接入、咨询师账户测试、测试案例集完善、回测报告 | 可演示的原型系统、验收报告 |

---

## 十九、结论

本文提出了一套完整、可计算、可解释、可接入系统的基于大数据和 AI 的高考志愿填报多目标推荐模型体系。五个核心模型覆盖了从分数标准化到最终志愿方案输出的全流程，七类数据采集器保障了数据来源的合规性和可追溯性。统一 JSON 接口使模型输出可直接服务于咨询系统、小程序或后台分析。经模拟数据验证，本体系能够有效降低滑档风险，提高志愿表的合理性。

本文所有模型和代码已预留真实数据接入接口。实际部署前需完成：真实数据爬取与清洗、按省份/科类/选科组合的分层模型训练与回测、A/B 测试校准权重、咨询师小范围内测和人工案例复核。

---

## 参考文献

[1] 教育部. 普通高等学校本科专业目录(2024年版)[Z]. 2024.
[2] 教育部. 全国普通高等学校名单[Z]. 2024.
[3] T. Chen, C. Guestrin. XGBoost: A Scalable Tree Boosting System[C]. KDD, 2016.
[4] C. L. Hwang, K. Yoon. Multiple Attribute Decision Making: Methods and Applications[M]. Springer, 1981.
[5] T. L. Saaty. The Analytic Hierarchy Process[M]. McGraw-Hill, 1980.
[6] C. E. Shannon. A Mathematical Theory of Communication[J]. Bell System Technical Journal, 1948.
[7] D. W. Hosmer, S. Lemeshow. Applied Logistic Regression[M]. Wiley, 2000.
[8] A. Gelman, et al. Bayesian Data Analysis[M]. CRC Press, 2013.

---

## 附录

### A. 爬虫伪代码

```
class SegmentTableCrawler(BaseCrawler):
    TABLE_NAME = "segment_table"
    def crawl_url_list(): return ["http://www.hebeea.edu.cn/2024/yifenyiduan.xlsx"]
    def parse_response(raw, url):
        if raw.endswith('.pdf'): return self.parse_pdf_tables(raw)
        if raw.endswith('.xlsx'): return self.parse_excel(raw)
        return self.parse_html_tables(raw)
    def run():
        for url in crawl_url_list():
            raw = fetch(url)
            df = parse_response(raw, url)
            df = validate_schema(df)
            df = add_source_trace(df)
            save_to_csv(df, f"data/segment_{year}.csv")
```

### B. 建模伪代码

**录取概率预测：**

```
输入: candidate_rank, historical_records, plan_series, profile_meta
1. 特征提取: extract_features() → {rank_gap_mean, rank_volatility, ...}
2. Logistic: p_lr = sigmoid(beta^T * x)
3. XGBoost: p_xgb = xgb.predict_proba(x)
4. 贝叶斯修正: p_bayes = (alpha0 + successes) / (alpha0 + beta0 + n)
5. 蒙特卡洛: M=10000次采样, p_mc = mean(I[cand_rank <= sim_rank])
6. 融合: p_final = 0.15*p_lr + 0.35*p_xgb + 0.20*p_bayes + 0.30*p_mc
7. 小样本处理: 若n<=2, 扩大CI宽度; review_required=True
8. 省份校正: province_subject_correction(p_final, province, subject_type)
9. tier映射: map_to_recommendation_tier(p_final)
输出: {admit_probability, probability_interval, recommendation_tier, ...}
```

### C. 统一 JSON 示例

参见第十四章结构。完整输出示例可通过 `python main.py --export-json result.json` 生成。

### D. 字段字典

| 字段组 | 关键字段 | 类型 | 来源表 | 说明 |
|--------|----------|------|--------|------|
| candidate | candidate_id, province, score, rank | str/int | candidate_profile | 考生基本信息 |
| candidate | equivalent_score, equivalent_rank, confidence_level | float/int/str | 模型一 | 等效换算结果 |
| volunteer | school_code, major_code, admit_probability | str/float | 模型一+二 | 单志愿预测 |
| volunteer | fit_score, career_score, city_score, family_score | float | 模型五+扩展 | 多维度评分 |
| volunteer | risk_level, review_required | str/bool | 模型四 | 逐志愿风险 |
| risk | overall_risk_score, slip_risk, ..., region_risk | float/dict | 模型四 | 综合与分项风险 |

### E. 测试案例表

详见第十六章 14 个案例，覆盖冲/稳/保/垫/高分/中分/低分/不调剂/排斥专业/预算受限/地域约束/异常年份/小样本/高风险专业。
